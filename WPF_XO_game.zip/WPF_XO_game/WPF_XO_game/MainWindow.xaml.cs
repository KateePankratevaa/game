﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPF_XO_game;
using XO_game;

namespace WPF_XO_game {
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow :Window {
        private readonly double rectWidth;
        private readonly double rectHeight;
        private readonly XOField XOGame = new XOField();

        public MainWindow () {

            InitializeComponent();
            // берем 1/3 от размеров всего поля
            rectWidth = gameField.Width / 3;
            rectHeight = gameField.Height / 3;

            XOGame.OnTurn += (row, col, elem) => {
                char symbol = elem == XOElement.Cross ? 'X' : 'O';
                printSymbol(row, col, symbol);
                if (gameField.Children.Count == 18 && XOGame.Winner == XOElement.None)
                {
                    MessageBox.Show("Ничья");
                }
            };
            // координата y левого верхнего угла текущей ячейки
            double y = 0;

            // три строки
            for (int i = 1; i <= 3; i++) {
                // координата x левого верхнего угла текущей ячейки
                double x = 0;

                // три ячейки в каждой строке
                for (int j = 1; j <= 3; j++) {
                    // создаем прямоугольник
                    var rect = new Rectangle();
                    rect.Stroke = Brushes.Black;
                    rect.StrokeThickness = 1;
                    rect.Height = rectHeight;
                    rect.Width = rectWidth;
                    // ставим ему координаты
                    Canvas.SetLeft(rect, x);
                    Canvas.SetTop(rect, y);
                    // добавляем на canvas
                    gameField.Children.Add(rect);
                    // уходим правее для отрисовки следующей ячейки
                    x += rectWidth;
                }
                // уходим ниже для отрисовки следующей строки
                y += rectHeight;
            }

            XOGame.OnGameOver += (winner) =>
            {
                if (winner == XOElement.Cross)
                {
                    MessageBox.Show("Победил X");
                }
                else if (winner == XOElement.Circle)
                {
                    MessageBox.Show("Победил O");
                }

            };
        }
        private (int, int) calcCell (double x, double y) {

            int row = (int) (y / rectHeight);
            int col = (int) (x / rectWidth);

            return (row, col);
        }

        // вывод символа в указанную ячейку
        private void printSymbol (int row, int col, char symbol) {

            (double cornerX, double cornerY) = (rectHeight * col, rectWidth * row);

            Label text = new Label();
            text.Content = symbol;
            text.FontSize = rectWidth / 1.5;

            Canvas.SetLeft(text, cornerX + rectWidth / 4);
            Canvas.SetTop(text, cornerY);
            gameField.Children.Add(text);
        }
        
        private void makeTurn (object sender, MouseButtonEventArgs e) {
            (int row, int col) = calcCell(e.GetPosition(gameField).X, e.GetPosition(gameField).Y);
            XOGame.TryTurn(row, col);
        }

        private void newgame_Click (object sender, RoutedEventArgs e) {
            XOGame.Clear();
            gameField.Children.Clear();
            // координата y левого верхнего угла текущей ячейки
            double y = 0;

            // три строки
            for (int i = 1; i <= 3; i++)
            {
                // координата x левого верхнего угла текущей ячейки
                double x = 0;

                // три ячейки в каждой строке
                for (int j = 1; j <= 3; j++)
                {
                    // создаем прямоугольник
                    var rect = new Rectangle();
                    rect.Stroke = Brushes.Black;
                    rect.StrokeThickness = 1;
                    rect.Height = rectHeight;
                    rect.Width = rectWidth;
                    // ставим ему координаты
                    Canvas.SetLeft(rect, x);
                    Canvas.SetTop(rect, y);
                    // добавляем на canvas
                    gameField.Children.Add(rect);
                    // уходим правее для отрисовки следующей ячейки
                    x += rectWidth;
                }
                // уходим ниже для отрисовки следующей строки
                y += rectHeight;
            }
        }

        private void exitgame_Click (object sender, RoutedEventArgs e) {
           Environment.Exit(0);
        }
    }
}
